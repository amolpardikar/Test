package com.webservices.rest.jersey.topic7.assignment2;

import com.webservices.rest.jersey.topic7.assignment1.*;
import com.webservices.rest.jersey.*;
import java.net.URI;

import javax.ws.rs.client.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

public class RESTfulJerseyClient {

	private static final String webServiceURI = "http://localhost:8080/RESTful_Jersey";

	public static void main(String[] args) {
		ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
		WebTarget webTarget = client.target(serviceURI);

                System.out.println(">>>>>");
		// response
		System.out.println(webTarget.path("rest").path("employee").path("getAll").request()
				.accept(MediaType.APPLICATION_XML).get(Response.class).toString());

                System.out.println(">>>>> APPLICATION_XML getAll");
		// xml
		System.out.println(webTarget.path("rest").path("employee").path("getAll").request()
				.accept(MediaType.APPLICATION_XML).get(String.class));
                
                System.out.println(">>>>> APPLICATION_XML location");
		// xml
		System.out.println(webTarget.path("rest").path("employee").path("location").path("mumbai").request()
				.accept(MediaType.APPLICATION_XML).get(String.class));
                
                System.out.println(">>>>> APPLICATION_XML band");
		// xml
		System.out.println(webTarget.path("rest").path("employee").path("band").path("C1").request()
				.accept(MediaType.APPLICATION_XML).get(String.class));
                
                System.out.println(">>>>> APPLICATION_XML delete");
		// xml
		//System.out.println(webTarget.path("rest").path("employee").path("delete").path("1").request()
		//		.accept(MediaType.APPLICATION_XML).get(ClientResponse.class));
                
                WebTarget deleteService = client.target("http://localhost:8080/RESTful_Jersey").path("employee").path("delete").path("1");
     
                Invocation.Builder invocationBuilder =  deleteService.request(MediaType.APPLICATION_XML);
                Response response = invocationBuilder.get();
     
                System.out.println(response.getStatus());
                System.out.println(response.getStatusInfo());

	}
}
