/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic7.assignment1;

import com.webservices.rest.jersey.topic7.assignment1.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBElement;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author amolpardikar
 */
@Path("/employee")
@Consumes(MediaType.APPLICATION_XML)

public class EmployeeService {
    @Context 
    UriInfo uriInfo;
    @Context 
    Request request;
    int stdId;
    
    public EmployeeService (){}
    
    public EmployeeService (UriInfo uriInfo, Request request, int id){
        this.uriInfo = uriInfo;
        this.request = request;
        this.stdId = id;
    }
    
    @GET
    @Path("/getAll")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Employee[] getAllEmployee() {
        Set<Integer> ids = EmployeeDAO.instance.getEmployees().keySet();
        Employee[] p = new Employee[ids.size()];
        int i = 0;
        for (Integer id : ids) {
            p[i] = EmployeeDAO.instance.getEmployees().get(id);
            i++;
        }
        return p;
    }
    
    @GET
    @Path("location/{loc}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Employee> getEmployeeByMLocation(@PathParam("loc") String loc) {
        List<Employee> employees = new ArrayList();
        employees.addAll(EmployeeDAO.instance.getEmployees().values());
        
        List<Employee> empLocationList = new ArrayList();
        for (Employee sts : employees){
            if (sts.getEmpLocation().equalsIgnoreCase(loc))
                empLocationList.add(sts);
        }
        return empLocationList;
    }
    
    @GET
    @Path("band/{bnd}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Employee> getEmployeeByBand(@PathParam("bnd") String bnd) {
        List<Employee> employees = new ArrayList();
        employees.addAll(EmployeeDAO.instance.getEmployees().values());
        
        List<Employee> empLocationList = new ArrayList();
        for (Employee sts : employees){
            if (sts.getEmpBand().equalsIgnoreCase(bnd))
                empLocationList.add(sts);
        }
        return empLocationList;
    }
  
    @POST
    @Consumes({MediaType.APPLICATION_XML})
    public Response addEmployee(JAXBElement<Employee> std) {
        Employee emp = std.getValue();
        return putAndGetResponse(emp);
    }
    
    private Response putAndGetResponse(Employee emp){
        Response res;
        if (EmployeeDAO.instance.getEmployees().containsKey(emp.getEmpId())){
            res = Response.noContent().build();
        } else {
            res = Response.created(uriInfo.getAbsolutePath()).build();
        }
        EmployeeDAO.instance.getEmployees().put(Integer.parseInt(emp.getEmpId()), emp);
        return res;
    }
 
    @PUT
    @Consumes({MediaType.TEXT_XML})
    public Response updateEmployee(JAXBElement<Employee> std) {
        Employee emp = std.getValue();
        return putAndGetResponse(emp);
    }

}
