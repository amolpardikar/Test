/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic7.assignment1;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amolpardikar
 */
@XmlRootElement(name = "employee")
public class Employee {
    private String empId;
    private String empFirstName;
    private String empLastName;
    private String empLocation;
    private String empBand;

    public Employee(){}
    
    public Employee(String id, String firstName, String lastName, String location, String band){
        this.empId = id;
        this.empFirstName = firstName;
        this.empLastName = lastName;
        this.empLocation = location;
        this.empBand = band;
    }

    /**
     * @return the empId
     */
    public String getEmpId() {
        return empId;
    }

    /**
     * @param empId the empId to set
     */
    public void setEmpId(String empId) {
        this.empId = empId;
    }

    /**
     * @return the empFirstName
     */
    public String getEmpFirstName() {
        return empFirstName;
    }

    /**
     * @param empFirstName the empFirstName to set
     */
    public void setEmpFirstName(String empFirstName) {
        this.empFirstName = empFirstName;
    }

    /**
     * @return the empLastName
     */
    public String getEmpLastName() {
        return empLastName;
    }

    /**
     * @param empLastName the empLastName to set
     */
    public void setEmpLastName(String empLastName) {
        this.empLastName = empLastName;
    }

    /**
     * @return the empLocation
     */
    public String getEmpLocation() {
        return empLocation;
    }

    /**
     * @param empLocation the empLocation to set
     */
    public void setEmpLocation(String empLocation) {
        this.empLocation = empLocation;
    }

    /**
     * @return the empBand
     */
    public String getEmpBand() {
        return empBand;
    }

    /**
     * @param empBand the empBand to set
     */
    public void setEmpBand(String empBand) {
        this.empBand = empBand;
    }
    
}
