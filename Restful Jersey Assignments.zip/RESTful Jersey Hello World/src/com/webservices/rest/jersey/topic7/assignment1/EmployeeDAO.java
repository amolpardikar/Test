/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic7.assignment1;

import com.webservices.rest.jersey.topic7.assignment1.Employee;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author amolpardikar
 */
public enum EmployeeDAO {
    instance;
    private Map<Integer, Employee> employee = new HashMap<Integer, Employee>();
    
    private EmployeeDAO(){
        
        employee.put(1, new Employee("1","ABC","CBA","Mumbai","C1"));
        employee.put(2, new Employee("2","AAA","AAA","Pune","C2"));
        employee.put(3, new Employee("3","BBB","BBB","Banglore","D1"));
    }
    
    public Map<Integer, Employee> getEmployees(){
        return employee;
    }
}
