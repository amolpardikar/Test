/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment2;

import com.webservices.rest.jersey.topic6.assignment2.Student;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author amolpardikar
 */
public enum StudentDAO {
    instance;
    private Map<Integer, Student> student = new HashMap<Integer, Student>();
    
    private StudentDAO(){
        
        student.put(1, new Student("1","ABC","9",89.9f));
        student.put(2, new Student("2","AAA","8",85.9f));
        student.put(3, new Student("3","BBB","7",82.9f));
    }
    
    public Map<Integer, Student> getStudents(){
        return student;
    }
}
