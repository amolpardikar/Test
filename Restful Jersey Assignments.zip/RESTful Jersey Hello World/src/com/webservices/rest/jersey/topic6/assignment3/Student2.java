/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment3;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amolpardikar
 */
@XmlRootElement(name = "student2")
public class Student2 {
    private String studentId;
    private String studentName;
    private String studentClass;
    private Float studentTotalMarks;

    public Student2(){}
    
    public Student2(String id, String name, String className, Float totalMarks){
        this.studentId = id;
        this.studentName = name;
        this.studentClass = className;
        this.studentTotalMarks = totalMarks;
    }
    /**
     * @return the studentId
     */
    public String getStudentId() {
        return studentId;
    }

    /**
     * @param studentId the studentId to set
     */
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    /**
     * @return the studentName
     */
    public String getStudentName() {
        return studentName;
    }

    /**
     * @param studentName the studentName to set
     */
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    /**
     * @return the studentClass
     */
    public String getStudentClass() {
        return studentClass;
    }

    /**
     * @param studentClass the studentClass to set
     */
    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }

    /**
     * @return the studentTotalMarks
     */
    public Float getStudentTotalMarks() {
        return studentTotalMarks;
    }

    /**
     * @param studentTotalMarks the studentTotalMarks to set
     */
    public void setStudentTotalMarks(Float studentTotalMarks) {
        this.studentTotalMarks = studentTotalMarks;
    }
    
    
}
