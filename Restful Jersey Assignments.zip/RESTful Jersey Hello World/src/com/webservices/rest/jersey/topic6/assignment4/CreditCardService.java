package com.webservices.rest.jersey.topic6.assignment4;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBElement;


@Path("/creditcard")
public class CreditCardService {
    
    @POST
    @Consumes({MediaType.APPLICATION_XML})
    public boolean validateCard(JAXBElement<CreditCard> ccd) {
       CreditCard cardDtls = ccd.getValue();

       int cardNo = cardDtls.getCreditCardNumber();

       if ((cardNo% 10) % 2 == 0)
           return true;
        else
           return false;
        }

}