/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment3;

import com.webservices.rest.jersey.topic6.assignment3.Student2;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author amolpardikar
 */
public enum StudentDAO2 {
    instance;
    private Map<Integer, Student2> student = new HashMap<Integer, Student2>();
    
    private StudentDAO2(){
        
        student.put(1, new Student2("1","ABC","9",89.9f));
        student.put(2, new Student2("2","AAA","8",85.9f));
        student.put(3, new Student2("3","BBB","7",82.9f));
    }
    
    public Map<Integer, Student2> getStudents(){
        return student;
    }
}
