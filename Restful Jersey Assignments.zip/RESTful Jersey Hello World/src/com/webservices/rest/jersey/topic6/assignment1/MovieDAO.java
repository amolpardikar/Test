/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment1;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author amolpardikar
 */
public enum MovieDAO {
    instance;
    private Map<Integer, Movie> movies = new HashMap<Integer, Movie>();
    
    private MovieDAO(){
        movies.put(1, new Movie(1,"DDLS","Sharukh",100000));
        movies.put(2, new Movie(2,"AAA","Salman",10000));
        movies.put(3, new Movie(3,"BBB","Aamir",100));
        movies.put(4, new Movie(4,"CCC","Ajay",10000));
        movies.put(5, new Movie(5,"DDD","Hrithik",100));
    }
    
    public Map<Integer, Movie> getMovies(){
        return movies;
    }
}
