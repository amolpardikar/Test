/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment3;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBElement;

import com.webservices.rest.jersey.topic6.assignment3.Student2;
import com.webservices.rest.jersey.topic6.assignment3.StudentDAO2;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author amolpardikar
 */
@Path("/student2")
@Consumes(MediaType.APPLICATION_XML)

public class StudentService2 {
    @Context 
    UriInfo uriInfo;
    @Context 
    Request request;
    int stdId;
    
    public StudentService2 (){}
    
    public StudentService2 (UriInfo uriInfo, Request request, int id){
        this.uriInfo = uriInfo;
        this.request = request;
        this.stdId = id;
    }
    
    @GET
    @Path("/getAll")
    @Produces({MediaType.APPLICATION_JSON})
    public Student2[] getAllStudent() {
        Set<Integer> ids = StudentDAO2.instance.getStudents().keySet();
        Student2[] p = new Student2[ids.size()];
        int i = 0;
        for (Integer id : ids) {
            p[i] = StudentDAO2.instance.getStudents().get(id);
            i++;
        }
        return p;
    }
    
    @GET
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_XML})
    public Student2 getStudentById(@PathParam("id") int id,
                                    @MatrixParam("studentId") String studentId) {
        Student2 student = null;
        if (studentId != null)
            student = StudentDAO2.instance.getStudents().get(Integer.parseInt(studentId));     
        else
            student = StudentDAO2.instance.getStudents().get(id); 
        
        if (student == null){
            throw new RuntimeException ("Student with "+ id + " not found");
        }
        
        return student;
    }
    
    @GET
    @Path("/marks/{marks}")
    @Produces({MediaType.APPLICATION_XML})
    public List<Student2> getStudentByMarks(@PathParam("marks") float marks,
                                            @MatrixParam("totalMarks") String totalMarks) {
        List<Student2> students = new ArrayList();
        
        float studentMarks = 0;
        if (totalMarks != null)
            studentMarks = Integer.parseInt(totalMarks);  
        else
            studentMarks = marks; 
        
        students.addAll(StudentDAO2.instance.getStudents().values());
        
        List<Student2> passedStudentsList = new ArrayList();
        for (Student2 sts : students){
            if (sts.getStudentTotalMarks() > studentMarks)
                passedStudentsList.add(sts);
        }
        return passedStudentsList;
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_XML})
    public Response addStudent(JAXBElement<Student2> std) {
        Student2 student = std.getValue();
        return putAndGetResponse(student);
    }
    
    private Response putAndGetResponse(Student2 std){
        Response res;
        if (StudentDAO2.instance.getStudents().containsKey(std.getStudentId())){
            res = Response.noContent().build();
        } else {
            res = Response.created(uriInfo.getAbsolutePath()).build();
        }
        StudentDAO2.instance.getStudents().put(Integer.parseInt(std.getStudentId()), std);
        return res;
    }
 
    @PUT
    @Consumes({MediaType.TEXT_XML})
    public Response updateStudent(JAXBElement<Student2> std) {
        Student2 student = std.getValue();
        return putAndGetResponse(student);
    }
    
    /*@DELETE
    public void deleteStudent(@PathParam("id") int id){
        Student2 std = StudentDAO2.instance.getStudents().remove(id); 
        if (std == null)
            throw new RuntimeException ("Student2 id with "+ id + " not found.");
    }*/

    @GET
    @Path("/{id}")
    @Produces({MediaType.TEXT_PLAIN})
    public List<Student2> getStudentByClass(@PathParam("cls") String cls, 
                                            @MatrixParam("className") String className) {
        List<Student2> students = new ArrayList();
        students.addAll(StudentDAO2.instance.getStudents().values());
        
        List<Student2> classStudentsList = new ArrayList();
        for (Student2 sts : students){
            if (sts.getStudentClass().equalsIgnoreCase(cls))
                classStudentsList.add(sts);
        }
        return classStudentsList;
    }
    
}
