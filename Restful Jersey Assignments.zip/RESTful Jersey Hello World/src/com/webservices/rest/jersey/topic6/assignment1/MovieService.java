/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment1;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBElement;

import com.webservices.rest.jersey.topic6.assignment1.Movie;
import com.webservices.rest.jersey.topic6.assignment1.MovieDAO;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author amolpardikar
 */
@Path("/movie")
@Consumes(MediaType.APPLICATION_XML)

public class MovieService {
    @Context 
    UriInfo uriInfo;
    @Context 
    Request request;
    int movId;
    
    public MovieService (){}
    
    public MovieService (UriInfo uriInfo, Request request, int id){
        this.uriInfo = uriInfo;
        this.request = request;
        this.movId = id;
    }
    
    @GET
    @Path("/getAll")
    @Produces({MediaType.TEXT_XML,MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Movie[] getAllMovies() {
        Set<Integer> ids = MovieDAO.instance.getMovies().keySet();
        Movie[] p = new Movie[ids.size()];
        int i = 0;
        for (Integer id : ids) {
            p[i] = MovieDAO.instance.getMovies().get(id);
            i++;
        }
        return p;
    }
    
    @GET
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_XML})
    public Movie getMovieById(@PathParam("id") int id) {
        Movie movie = MovieDAO.instance.getMovies().get(id);     
        
        if (movie == null){
            throw new RuntimeException ("Get Movie with "+ id + " not found");
        }
        
        return movie;
    }
    
    @GET
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Movie> getMovies() {
        List<Movie> movies = new ArrayList();
        movies.addAll(MovieDAO.instance.getMovies().values());
        return movies;
    }
    
    @GET
    @Path("count")
    @Produces({MediaType.TEXT_PLAIN})
    public int getCount() {
        int count = MovieDAO.instance.getMovies().size();
        return count;
    }
}
