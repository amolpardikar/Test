/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment1;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amolpardikar
 */
@XmlRootElement(name = "movie")
public class Movie {

    private int movieId;
    private String movieName;
    private String movieActor;
    private float movieCollection;
    
    public Movie(){}
    
    public Movie (int id, String name, String actor, float collection) {
        this.movieId = id ;
        this.movieName = name;
        this.movieActor = actor;
        this.movieCollection = collection;
    }
   /**
     * @return the movieId
     */
    public int getMovieId() {
        return movieId;
    }

    /**
     * @param movieId the movieId to set
     */
    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    /**
     * @return the movieName
     */
    public String getMovieName() {
        return movieName;
    }

    /**
     * @param movieName the movieName to set
     */
    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    /**
     * @return the movieActor
     */
    public String getMovieActor() {
        return movieActor;
    }

    /**
     * @param movieActor the movieActor to set
     */
    public void setMovieActor(String movieActor) {
        this.movieActor = movieActor;
    }

    /**
     * @return the movieCollection
     */
    public float getMovieCollection() {
        return movieCollection;
    }

    /**
     * @param movieCollection the movieCollection to set
     */
    public void setMovieCollection(float movieCollection) {
        this.movieCollection = movieCollection;
    }

    @Override
    public String toString() {
        return getMovieId() + "::" + getMovieName() + "::" + getMovieActor() + "::" + getMovieCollection();
    }
}
