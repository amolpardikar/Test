/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment2;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBElement;

import com.webservices.rest.jersey.topic6.assignment2.Student;
import com.webservices.rest.jersey.topic6.assignment2.StudentDAO;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author amolpardikar
 */
@Path("/student")
@Consumes(MediaType.APPLICATION_XML)

public class StudentService {
    @Context 
    UriInfo uriInfo;
    @Context 
    Request request;
    int stdId;
    
    public StudentService (){}
    
    public StudentService (UriInfo uriInfo, Request request, int id){
        this.uriInfo = uriInfo;
        this.request = request;
        this.stdId = id;
    }
    
    @GET
    @Path("/getAll")
    @Produces({MediaType.APPLICATION_JSON})
    public Student[] getAllStudent() {
        Set<Integer> ids = StudentDAO.instance.getStudents().keySet();
        Student[] p = new Student[ids.size()];
        int i = 0;
        for (Integer id : ids) {
            p[i] = StudentDAO.instance.getStudents().get(id);
            i++;
        }
        return p;
    }
    
    @GET
    @Path("/{id}")
    @Produces({MediaType.APPLICATION_XML})
    public Student getStudentById(@PathParam("id") int id) {
        Student student = StudentDAO.instance.getStudents().get(id);     
        
        if (student == null){
            throw new RuntimeException ("Student with "+ id + " not found");
        }
        
        return student;
    }
    
    @GET
    @Path("/{id}")
    @Produces({MediaType.TEXT_PLAIN})
    public List<Student> getStudentByMarks(@PathParam("marks") float marks) {
        List<Student> students = new ArrayList();
        students.addAll(StudentDAO.instance.getStudents().values());
        
        List<Student> studentsList = new ArrayList();
        for (Student sts : students){
            if (sts.getStudentTotalMarks() > marks)
                studentsList.add(sts);
        }
        return studentsList;
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_XML})
    public Response addStudent(JAXBElement<Student> std) {
        Student student = std.getValue();
        return putAndGetResponse(student);
    }
    
    private Response putAndGetResponse(Student std){
        Response res;
        if (StudentDAO.instance.getStudents().containsKey(std.getStudentId())){
            res = Response.noContent().build();
        } else {
            res = Response.created(uriInfo.getAbsolutePath()).build();
        }
        StudentDAO.instance.getStudents().put(Integer.parseInt(std.getStudentId()), std);
        return res;
    }
 
    @PUT
    @Consumes({MediaType.TEXT_XML})
    public Response updateStudent(JAXBElement<Student> std) {
        Student student = std.getValue();
        return putAndGetResponse(student);
    }
    
    @DELETE
    public void deleteStudent(@PathParam("id") int id){
        Student std = StudentDAO.instance.getStudents().remove(id); 
        if (std == null)
            throw new RuntimeException ("Student id with "+ id + " not found.");
    }

}
