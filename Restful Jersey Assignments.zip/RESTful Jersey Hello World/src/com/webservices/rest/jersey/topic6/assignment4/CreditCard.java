/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webservices.rest.jersey.topic6.assignment4;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amolpardikar
 */
@XmlRootElement(name = "card")
public class CreditCard {
    private int creditCardNumber;
    
    public CreditCard(){}
    
    public CreditCard(int cardNumber){
        this.creditCardNumber = cardNumber;
    }

    /**
     * @return the creditCardNumber
     */
    public int getCreditCardNumber() {
        return creditCardNumber;
    }

    /**
     * @param creditCardNumber the creditCardNumber to set
     */
    public void setCreditCardNumber(int creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }
    
}
